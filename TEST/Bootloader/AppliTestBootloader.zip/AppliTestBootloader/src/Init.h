/*
 * Init.h
 *
 *  Created on: 1 févr. 2014
 *      Author: Fixe
 */

#ifndef INIT_H_
#define INIT_H_

#include "Includes.h"

void Init_Robot(void);

#endif /* INIT_H_ */
