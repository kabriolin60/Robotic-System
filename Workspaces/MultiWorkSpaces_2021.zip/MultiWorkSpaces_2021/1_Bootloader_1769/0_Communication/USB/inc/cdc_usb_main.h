/*
 * cdc_usb_main.h
 *
 *  Created on: 13 avr. 2020
 *      Author: kabri
 */

#ifndef USB_INC_CDC_USB_MAIN_H_
#define USB_INC_CDC_USB_MAIN_H_

int usb_main(void);

#endif /* USB_INC_CDC_USB_MAIN_H_ */
