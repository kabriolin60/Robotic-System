/*
 * Init.h
 *
 *  Created on: 27 déc. 2020
 *      Author: kabri
 */

#ifndef INC_INIT_H_
#define INC_INIT_H_

void Init_Carte_Perpheriques(void);

void vConfigureTimerForRunTimeStats( void );

#endif /* INC_INIT_H_ */
