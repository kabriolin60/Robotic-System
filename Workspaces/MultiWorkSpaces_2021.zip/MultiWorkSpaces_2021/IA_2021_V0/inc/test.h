/*
 * test.h
 *
 *  Created on: 2 mai 2020
 *      Author: kabri
 */

#ifndef TEST_H_
#define TEST_H_

void TEST_init_parametres(void);

void TEST_Strategie_2021(void* pvParameter);

void TEST_Deplacement_Reel(void * pvParameter);

void TEST_Deplacement(void * pvParameter);

void TEST_Deplacement2(void * pvParameter);

void TEST_envoi_Ping(void *pvParameters);

#endif /* TEST_H_ */
