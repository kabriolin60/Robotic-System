/*
 * 1_Obstacles.h
 *
 *  Created on: 13 mai 2020
 *      Author: kabri
 */

#ifndef _1_OBSTACLES_H_
#define _1_OBSTACLES_H_


void _1_Obstacles_Create_Terrain_Border(void);

void _1_TEST_Obstacles_Opponent_Robots(void);


#endif /* 0_DEPLACEMENT_1_OBSTACLES_H_ */
